<?php
/**
 * @In the name of God!
 * @author: Iman Moodi (Iman92)
 * @email: info@apadanacms.ir
 * @link: http://www.apadanacms.ir
 * @license: http://www.gnu.org/licenses/
 * @copyright: Copyright © 2012-2015 ApadanaCms.ir. All rights reserved.
 * @Apadana CMS is a Free Software
 */

defined('security') or exit('Direct Access to this location is not allowed.');

function module_account_info()
{
	return array(
		'name' => 'سامانه ی کاربری',
		'version' => '1.0',
		'creation-date' => '2012-07-21 18:00:03',
		'description' => 'ماژول سامانه کاربری آپادانا',
		'author' => 'Apadana Development Team',
		'author-email' => 'imanmoodi@yahoo.com',
		'author-url' => 'http://www.apadanacms.ir',
		'license' => 'GNU/GPL',
	);
}

function module_account_admin()
{
	global $tpl, $d, $options, $cache;

	member::check_admin_page_access('account') or warning('عدم دسترسی!', 'شما دسترسی لازم برای مشاهده این بخش را ندارید!');
	require_once(root_dir.'modules/account/functions.admin.php');

	$_GET['do'] = get_param($_GET, 'do');

	switch($_GET['do'])
	{
		case 'edit';
		_edit();
		break;

		case 'status';
		_status();
		break;
		
		case 'options';
		_options();
		break;

		case 'new';
		_new();
		break;
		
		default:
		_default();
		break;
	}
}

?>