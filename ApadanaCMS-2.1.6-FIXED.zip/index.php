<?php
/**
 * @In the name of God!
 * @author: Iman Moodi (Iman92)
 * @email: info@apadanacms.ir
 * @link: http://www.apadanacms.ir
 * @license: http://www.gnu.org/licenses/
 * @copyright: Copyright © 2012-2015 ApadanaCms.ir. All rights reserved.
 * @Apadana CMS is a Free Software
 */

@ob_start();
@ob_implicit_flush(0);
@ini_set('session.cookie_httponly', '1');
@ini_set('session.use_only_cookies', '1');
@ini_set('session.use_strict_mode', '1');
@session_start();

@error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);
@ini_set('display_errors', '0');
@ini_set('html_errors', false);
@ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);

define('security', true);
define('root_dir', dirname(__FILE__).'/');
define('engine_dir', root_dir.'engine/');

/**
* @since 1.1
*/
define('modules_dir', root_dir.'modules/');

define('disable_gzip', true);
require_once(engine_dir.'init.php');

if ( admin_page )
{
	define('home', false);
	require_once(engine_dir.'admin/init.php');
}
else
{
	check_url();

	if (!isset($_GET['a']))
	{
		$_GET['a'] = '';
	}

	if (mod_rewrite !== 'error' && $_GET['a'] === '')
	{
		define('home', true);
		$_GET['a'] = isset($options['default-module']) ? $options['default-module'] : 'posts';
	}
	else
	{
		define('home', false);
	}
	$__mod = preg_replace('/[^a-z0-9\-]/i', '', (string)$_GET['a']);
	$_GET['a'] = $__mod;
	if (mod_rewrite !== 'error' && $__mod !== '' && is_module($__mod) && function_exists('module_'.str_replace('-', '_', $__mod).'_run'))
	{
		call_user_func('module_'.str_replace('-', '_', $__mod).'_run');
	}
	else
	{
		module_error_run('404');
	}
}

if (!defined('no_headers') || no_headers === false)
{
    header('Content-type: text/html; charset='.charset);
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
    header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
}

if (!defined('no_template') || no_template !== true)
{
	if (admin_page === false && !is_ajax())
	{
		require_once(engine_dir.'http-referer.function.php');
		http_referer();
		update_session();
	}

	if (!defined('no_blocks') || no_blocks !== true)
	{
		require_once(engine_dir.'block.function.php');
		blocks();
	}

	if (isset($tpl->foreach['pagination']))
	{
		$tpl->assign(array(
			'[pagination]' => null,
			'[/pagination]' => null,
		));
	}
	else
	{
		$tpl->block('#\\[pagination\\](.*?)\\[/pagination\\]#s', '');
	}

	$tpl->assign(array(
		'{head}' => head(),
		'{foot}' => (isset($page['foot']) && is_array($page['foot']) && count($page['foot'])) ? implode(n, $page['foot']).n : '',
		'{num-queries}' => translate_number($d->num_queries),
		'{creation-time}' => translate_number(apadana_substr(microtime(true)-start_time, 0, debug_system? 7 : 4)),
		'{memory-get-usage}' => translate_number(apadana_memory_get_usage())
	));

	if ($options['allow-change-theme']) {
		$tpl->assign('{templates-list}' , get_templates(true));
	}else{
		$tpl->assign('{templates-list}' , 'تغیر قالب غیر فعال است');
	}

	if (home === true)
	{
		set_theme('home');
	}

	if (is_alphabet($page['theme']) && !admin_page && file_exists($tpl->base_dir.$page['theme'].'.tpl'))
	{
		$tpl->load($page['theme'].'.tpl');
	}

	($hook = get_hook('index'))? eval($hook) : null;

	$tpl->tags['{content}'] = '<div id="apadana-ajax-content">'.(isset($tpl->tags['{content}'])? $tpl->tags['{content}'] : null).'</div>';
	$tpl->display();
}

gzip_out();