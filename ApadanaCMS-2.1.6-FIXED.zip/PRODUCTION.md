# Apadana CMS — راهنمای کامل تولید (Production)

**نسخه فعلی هسته:** `2.1.5`  
**پایه کد:** شاخه develop گیت‌هاب Apadana (نگارش ۱.۱-آلفا) + مدرن‌سازی امنیتی و PHP 8  
**مخاطب:** استقرار روی هاست واقعی

---

## ۱. پیشینه پروژه (از نسخه اول تا امروز)

### ۱.۱ نسخه اولی که ارسال شد
- سیستم مدیریت محتوای ایرانی **Apadana** مربوط به حدود سال **۱۳۹۲ شمسی**
- کد قدیمی با وابستگی به PHP قدیمی (`mysql_*`، `create_function`، `preg_replace /e`، `each()` و …)
- هش رمز عبور با `md5(sha1(...))`
- کتابخانه‌های جانبی قدیمی (CKEditor، PHPMailer، elFinder، TCPDF و …)
- بدون CSRF، بدون prepared statements، بدون rate-limit ورود

### ۱.۲ مسیر کار (خلاصه زمانی)

| مرحله | موضوع |
|--------|--------|
| شروع | بررسی ایرادات نسخه قدیمی و سازگاری با PHP 8 |
| هسته امنیتی | `password_hash`، CSRF، prepared statements، حذف `/e` |
| رفع خطاهای نصب/اجرا | `create_function`، Gzip/Encoding، صفحه سفید، null در PHP 8 |
| پنل و ماژول‌ها | counter، jdate، backup، voting، media، PDF، ثبت‌نام |
| ماژول دانلود | افزونه حرفه‌ای با تب‌بندی شبیه shop، آپلود با پیشرفت، فایل‌های آپلود‌شده |
| انتقال به develop | پایه از GitHub develop (۱.۱) به‌جای ۱.۰ صرف |
| ۲.۱.x | mysqli اجباری، CSP، جایگزینی elFinder، مهاجرت SQL، production-ready |

### ۱.۳ نسخه GitHub develop نسبت به ۱.۰ اولیه چه داشت؟
- پشتیبانی **mysqli** (در کنار mysql قدیمی)
- CKEditor و PHPMailer به‌روزتر نسبت به ۱.۰
- حذف TCPDF و GeoIP از هسته develop
- `option.function.php`، pagination با نام‌های کوچک
- کپچای فارسی، آرشیو پست، تقویم، موضوعات سلسله‌مراتبی
- سیستم قلاب (hooks)، فیلد compatibility ماژول‌ها

با این حال از نظر **امنیت مدرن و PHP 8** هنوز ناکافی بود؛ لایه‌های ۲.۱ روی همان پایه اعمال شد.

---

## ۲. فهرست تغییرات امنیتی و فنی (از اول تا ۲.۱.۵)

### ۲.۱ احراز هویت و رمز عبور
- انتقال از `md5(sha1)` به **`password_hash()` / `password_verify()`**
- تابع **`member::check_password()`** با سازگاری عقب‌رو (هش قدیم + bcrypt/argon)
- **ارتقا خودکار هش** هنگام ورود موفق با رمز قدیمی
- در نصب: ساخت ادمین با `password_hash`
- ستون پیشنهادی: `member_password VARCHAR(255)`
- **Rate-limit ورود** (جلوگیری از brute-force در session)

### ۲.۲ پایگاه‌داده و SQL Injection
- **الزام mysqli** — حذف مسیرهای `mysql_*`
- متدهای **`prepare_query` / `prepare_fetch` / `prepare_num_rows`**
- مهاجرت ده‌ها کوئری حساس در:
  - لاگین ادمین و کاربری
  - ماژول posts (فرانت و ادمین)
  - comments، blocks، banned
  - account (ثبت‌نام، ایمیل، فراموشی رمز، session، جستجوی اعضا)
- سخت‌سازی LIKE جستجو (`%` / `_`) و whitelist برای ORDER BY

### ۲.۳ CSRF و Session
- توابع **`csrf_token` / `csrf_field` / `csrf_check`**
- Session: `cookie_httponly`، `use_only_cookies`، `use_strict_mode`
- هدرهای امنیتی در PHP و `.htaccess`

### ۲.۴ XSS و قالب
- تبدیل `preg_replace /e` در template و **BBCode** به `preg_replace_callback`
- **whitelist توابع** قابل فراخوانی از تگ‌های قالب + لیست سیاه توابع خطرناک
- **`sanitize_user_html()`** برای نظرات
- **`safe_search_term()`** برای جستجو
- محدودسازی محتوای CKEditor (مسدود script/iframe/رویدادهای on*)

### ۲.۵ فایل و رسانه
- **جایگزینی elFinder** با مدیریت رسانه محدود به `uploads/`
- غیرفعال‌سازی connector قدیمی elFinder
- لیست پسوند مجاز + جلوگیری از path traversal
- **`.htaccess` ضد اجرای PHP** در `uploads/`
- ماژول **downloads** (جدا/همراه بسته): آپلود امن، تب فایل‌های آپلود‌شده، صفحه‌بندی، ارتباط با عنوان دانلود

### ۲.۶ کتابخانه‌ها
- **PHPMailer 6.9.3** (TLS/SMTPS، اعتبارسنجی ایمیل)
- CKEditor سری ۴ با **config امن‌تر** (نه ارتقا کامل به CKEditor 5 به‌خاطر حجم/سازگاری)
- اصلاحات مرتبط با PHP 8 در فیلتر، template، html class و …

### ۲.۷ نصب و استقرار
- `member_password` به **VARCHAR(255)** در SQL نصب
- اسکریپت ارتقا برای نصب‌های قبلی
- **قفل installer** پس از وجود `config.inc.php` (مگر `install/reinstall.allow`)
- پیش‌فرض **`debug_system = false`**
- `display_errors = Off` در `index.php` برای production
- `.htaccess` ریشه: مسدود کردن config، فایل‌های حساس، و ترجیحاً install

### ۲.۸ سایر رفع‌های عملیاتی (مسیر گفتگو)
- خطای `create_function` در نصب
- صفحه سفید / Content Encoding (Gzip)
- null به توابع رشته در PHP 8
- آمارگیر counter، نمایش jdate، backup، voting
- ثبت‌نام کاربر، لاگین ادمین، رمز ادمین
- ماژول دانلود با UI شبیه shop و نوار پیشرفت آپلود

---

## ۳. پیش‌نیاز سرور (Production)

| مورد | حداقل | توصیه |
|------|--------|--------|
| PHP | 8.0 | 8.1 یا 8.2 |
| افزونه‌ها | mysqli, mbstring, openssl, json, session, filter | + zip, gd |
| دیتابیس | MySQL 5.7 / MariaDB 10.3 | MySQL 8 / MariaDB 10.6+ |
| وب‌سرور | Apache یا Nginx | Apache + mod_rewrite + mod_headers |

---

## ۴. نصب امن روی هاست

1. آپلود محتویات بسته و استخراج.
2. دسترسی نوشتن برای:
   - `uploads/`
   - `engine/cache/` (در صورت وجود)
3. ایجاد دیتابیس MySQL و کاربر با دسترسی محدود به همان دیتابیس.
4. اجرای نصب از مسیر `/install/`
5. **بلافاصله بعد از نصب:**
   - پوشه `install` را حذف یا تغییر نام دهید؛
   - یا بدون فایل `install/reinstall.allow` نصب مجدد مسدود است.
6. در `engine/config.inc.php` تأیید کنید:

```php
define('debug_system', false);
```

7. HTTPS را فعال و HTTP را به HTTPS ریدایرکت کنید.
8. رمز ادمین قوی تنظیم کنید.

### ارتقا از نصب قدیمی (قبل از ۲.۱)

```sql
ALTER TABLE `PREFIX_members`
  MODIFY `member_password` VARCHAR(255) NOT NULL DEFAULT '';
```

با اولین ورود موفق، هش قدیمی در صورت صحت رمز به `password_hash` ارتقا می‌یابد.

---

## ۵. چک‌لیست امنیت قبل از Go-Live

- [ ] `debug_system = false`
- [ ] `display_errors` خاموش
- [ ] پوشه `install` حذف شده
- [ ] HTTPS فعال
- [ ] `member_password` به VARCHAR(255) ارتقا یافته (در صورت دیتابیس قدیمی)
- [ ] رمز ادمین قوی
- [ ] بکاپ منظم فایل + دیتابیس
- [ ] افزونه/قالب فقط از منبع مورد اعتماد
- [ ] دسترسی FTP/SSH محدود
- [ ] مجوز پوشه‌ها ترجیحاً ۷۵۵/۶۴۴ (نه ۷۷۷ عمومی)

---

## ۶. معماری امنیتی نسخه فعلی (خلاصه فنی)

```
index.php
  → session harden + error reporting محدود
  → engine/init.php
       → هدرهای X-Frame / nosniff / Referrer-Policy / CSP
       → database (mysqli + prepare_*)
       → member (password_hash / check_password)
       → functions (csrf_*, rate-limit, sanitize_*)
  → ماژول‌ها / ادمین
```

**نکته:** همه کوئری‌های همه ماژول‌ها هنوز prepared نیستند؛ مسیرهای حساس (ورود، هویت، پست، نظر، اعضا) پوشش داده شده و بقیه با escape/whitelist محافظت می‌شوند.

---

## ۷. محدودیت‌های باقی‌مانده (واقع‌بینانه)

1. **CKEditor 5** جایگزین کامل نشده؛ سری ۴ با فیلتر محتوا امن‌تر شده است.
2. **قلاب‌های `eval($hook)`** فقط برای کد مورد اعتماد ادمین است — افزونه ناشناس نصب نکنید.
3. مهاجرت ۱۰۰٪ همه SQLها به prepared نیاز به نگهداری تدریجی دارد.
4. هیچ نرم‌افزاری بدون به‌روزرسانی مداوم «بدون نگرانی مطلق» نیست؛ این نسخه برای هاست واقعی **قابل استقرار** است اگر چک‌لیست بالا رعایت شود.

---

## ۸. جدول نسخه‌های مدرن‌سازی این شاخه

| نسخه | محور |
|------|------|
| ۲.۰.x | مدرن‌سازی روی بسته ۱.۰ اولیه کاربر (PHP 8، رمز، CSRF، …) |
| ۲.۱.۰ | پایه GitHub develop + password_hash + prepare پایه + CSRF |
| ۲.۱.۱ | حذف mysql_*، CSP، media امن، VARCHAR(255) نصب |
| ۲.۱.۲ | مهاجرت prepared در posts/admin |
| ۲.۱.۳ | ادامه account/session/جستجو/نظرات مرتبط |
| ۲.۱.۴ | production: htaccess، قفل install، whitelist قالب، BBCode بدون /e |
| **۲.۱.۵** | PHPMailer 6.9.3، CKEditor harden، sanitize نظرات و جستجو |

---

## ۹. پشتیبانی و نگهداری پیشنهادی

- پس از هر تغییر ماژول، ورودی‌های کاربر را با `prepare_*` یا حداقل `escape_string` + اعتبارسنجی نوع بررسی کنید.
- لاگ خطای PHP را در سطح سرور (نه نمایش به کاربر) فعال نگه دارید.
- هر چند ماه یک‌بار بکاپ تست بازیابی بگیرید.
- قبل از نصب افزونه جدید: بررسی کد برای `eval`، `$_GET` در SQL خام، آپلود بدون پسوند سفید.

---

## ۱۰. درباره CVEهای مطرح‌شده در مسیر توسعه

- **CVE-2022-4898:** مربوط به Octopus Server است — در آپادانا نیست.
- **CVE-2022-4892:** XSS در `lib/gener/view.php` ماژول Visitors مربوط به **MyCMS** است — مسیر و ماژول در آپادانا وجود ندارد.

---

## ۱۱. جمع‌بندی

از یک CMS قدیمی (~۱۳۹۲) با ضعف‌های شناخته‌شده PHP قدیمی، به شاخه‌ای بر پایه **Apadana develop 1.1** رسیده‌اید که:

- روی **PHP 8.x** قابل اجراست؛
- مسیرهای اصلی در برابر **SQLi / XSS / brute-force رمز / آپلود مخرب** سخت‌سازی شده‌اند؛
- برای **هاست واقعی** با رعایت بخش ۴ و ۵ این سند قابل استفاده است.

**آخرین بسته انتشار پیشنهادی:** `ApadanaCMS-2.1.5.zip`  
**این سند:** `PRODUCTION.md`
