<?php
header('Content-Type: text/plain; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', '1');
echo "PHP ".PHP_VERSION."\n";
define('security', true);
define('root_dir', __DIR__.'/');
define('engine_dir', root_dir.'engine/');
define('modules_dir', root_dir.'modules/');
echo "config: ".(file_exists(engine_dir.'config.inc.php')?'yes':'no')."\n";
echo "install dir: ".(is_dir(root_dir.'install')?'yes':'no')."\n";
try {
  require engine_dir.'init.php';
  echo "INIT OK\n";
  echo "url=".(defined('url')?url:'?')."\n";
  echo "member defined\n";
} catch (Throwable $e) {
  echo "THROW: ".$e->getMessage()."\n".$e->getFile().":".$e->getLine()."\n";
}
echo "DONE - delete debug-boot.php\n";
