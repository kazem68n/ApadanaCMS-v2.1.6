# Apadana CMS 2.1.0

**پایه:** شاخه develop گیت‌هاب (نگارش ۱.۱-آلفا)  
**هدف:** امنیت مدرن + سازگاری PHP 8.x + حفظ امکانات ۱.۱

## تفاوت پایه ۱.۱ نسبت به ۱.۰.x اولیه
- پشتیبانی mysqli (دوگانه با mysql قدیمی)
- CKEditor جدیدتر، PHPMailer به‌روزتر
- حذف TCPDF و GeoIP از هسته
- option.function.php، pagination با حروف کوچک
- کپچای فارسی، آرشیو پست، تقویم، موضوعات سلسله‌مراتبی
- سیستم قلاب (hooks)، فیلد compatibility ماژول‌ها

## تغییرات امنیتی و فنی ۲.۱ (روی پایه ۱.۱)
1. **password_hash / password_verify** با سازگاری عقب‌رو برای md5(sha1)
2. **ارتقا خودکار هش** هنگام ورود موفق با رمز قدیمی
3. **Prepared Statements** در database.class (`prepare_query`, `prepare_fetch`, `prepare_num_rows`)
4. **الزام mysqli** (حذف وابستگی به mysql_* حذف‌شده در PHP ۷+)
5. **CSRF** (`csrf_token`, `csrf_field`, `csrf_check`)
6. **Rate-limit ورود**
7. **هدرهای امنیتی** و سخت‌سازی session
8. حذف **create_function** از template
9. جایگزینی `$str{$i}` با `$str[$i]` برای PHP ۸
10. free_result/close امن در برابر mysqli_result بسته‌شده

## کارهای توصیه‌شده بعدی
- مهاجرت تدریجی کوئری‌های ماژول‌ها به prepare_*
- جایگزینی elFinder
- CSP سخت‌تر
- به‌روزرسانی CKEditor/PHPMailer به آخرین نسخه پایدار
- افزودن ماژول downloads مدرن (نسخه جدا موجود است)

## ارتقا از نصب قبلی
```sql
ALTER TABLE `PREFIX_members`
  MODIFY `member_password` VARCHAR(255) NOT NULL DEFAULT '';
```

## 2.1.1 (امنیت ادامه)

- حذف کامل مسیر `mysql_*` از database.class
- CSP + Permissions-Policy
- media manager امن جایگزین elFinder (connector غیرفعال)
- VARCHAR(255) برای member_password در نصب + اسکریپت ارتقا
- password_hash هنگام نصب ادمین
- prepared برای لاگین account و برخی کوئری‌های posts
- .htaccess ضد اجرای PHP در uploads

### CVE-2022-4898 / CVE-2022-4892
- **CVE-2022-4898**: مربوط به **Octopus Server** است — در آپادانا وجود ندارد.
- **CVE-2022-4892** (احتمالاً منظور کاربر): XSS در `lib/gener/view.php` ماژول Visitors مربوط به **MyCMS** (andrzuk/MyCMS) است — این مسیر و ماژول در آپادانا وجود ندارد.
- در آپادانا مسیر مشابه `engine/feedGenerator/lib/*generator*` فقط برای RSS/Atom است و ورودی کاربران را به‌صورت HTML صفحه Visitors رندر نمی‌کند.
