<?php defined('security') or exit('Direct Access to this location is not allowed.'); define('version', '2.1.6');
