<?php
/**
 * Mail helper — PHPMailer 6.9.x
 */
defined('security') or exit('Direct Access to this location is not allowed.');

function send_mail($toname, $toemail, $fromname, $fromemail, $subject, $message, $type = 'apadana', $cc = null, $bcc = null)
{
	global $options;

	require_once engine_dir.'PHPMailer/src/Exception.php';
	require_once engine_dir.'PHPMailer/src/PHPMailer.php';
	require_once engine_dir.'PHPMailer/src/SMTP.php';

	$mail = new \PHPMailer\PHPMailer\PHPMailer(true);

	($hook = get_hook('send_mail_start')) ? eval($hook) : null;

	try
	{
		$mail->CharSet = defined('charset') ? charset : 'UTF-8';
		$mail->Encoding = 'base64';

		if (empty($options['smtp-host']) || empty($options['smtp-username']) || empty($options['smtp-password']))
		{
			$mail->isMail();
		}
		else
		{
			$mail->isSMTP();
			$mail->Host = $options['smtp-host'];
			$mail->Port = !empty($options['smtp-port']) ? (int) $options['smtp-port'] : 587;
			$mail->SMTPAuth = true;
			$mail->Username = $options['smtp-username'];
			$mail->Password = $options['smtp-password'];
			# TLS by default on 587
			if ($mail->Port === 465)
			{
				$mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
			}
			else
			{
				$mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
			}
		}

		$fromemail = filter_var($fromemail, FILTER_VALIDATE_EMAIL) ? $fromemail : '';
		$toemail = filter_var($toemail, FILTER_VALIDATE_EMAIL) ? $toemail : '';
		if ($fromemail === '' || $toemail === '')
		{
			return false;
		}

		if (!$toname) $toname = $toemail;
		if (!$fromname) $fromname = $fromemail;

		$mail->setFrom($fromemail, $fromname);
		$mail->addAddress($toemail, $toname);
		$mail->addReplyTo($fromemail, $fromname);

		if ($cc)
		{
			foreach (array_map('trim', explode(',', $cc)) as $ccaddress)
			{
				if (filter_var($ccaddress, FILTER_VALIDATE_EMAIL))
					$mail->addCC($ccaddress);
			}
		}
		if ($bcc)
		{
			foreach (array_map('trim', explode(',', $bcc)) as $bccaddress)
			{
				if (filter_var($bccaddress, FILTER_VALIDATE_EMAIL))
					$mail->addBCC($bccaddress);
			}
		}

		$mail->Subject = $subject;
		if ($type === 'plain')
		{
			$mail->isHTML(false);
			$mail->Body = $message;
		}
		else
		{
			$mail->isHTML(true);
			$mail->Body = $message;
			$mail->AltBody = strip_tags(str_replace(array('<br>', '<br/>', '<br />'), "\n", $message));
		}

		($hook = get_hook('send_mail_before_send')) ? eval($hook) : null;

		$ok = $mail->send();
		($hook = get_hook('send_mail_end')) ? eval($hook) : null;
		return $ok;
	}
	catch (\PHPMailer\PHPMailer\Exception $e)
	{
		if (defined('debug_system') && debug_system)
		{
			# only log when debugging
		}
		return false;
	}
}
