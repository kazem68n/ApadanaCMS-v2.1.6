<?php
/**
 * @In the name of God!
 * @author: Iman Moodi (Iman92)
 * @email: info@apadanacms.ir
 * @link: http://www.apadanacms.ir
 * @license: http://www.gnu.org/licenses/
 * @copyright: Copyright © 2012-2015 ApadanaCMS.ir. All rights reserved.
 * @Apadana CMS is a Free Software
 */

defined('security') or exit('Direct Access to this location is not allowed.');

class database
{
	private $mysqli = false;
	public $connect = null;
	public $num_queries = 0;
	public $query_time = 0;
	public $debug = false;
	public $prefix = null;
	public $result = null;
	public $charset = null;
	public $save_queries = false;
	public $queries = array();

	public function connect($db) 
	{		
		$this->mysqli = extension_loaded('mysqli');
		if (!$this->mysqli) { exit('Apadana 2.1 requires the mysqli PHP extension.'); }
		$this->debug = debug_system;
		$this->save_queries = defined('database_save_queries') && database_save_queries? true : false;
		$this->prefix = $db['prefix'];
		$this->charset = $db['charset'];

		$this->connect = @mysqli_connect($db['host'], $db['user'], $db['password']);
		if (!$this->connect)
		{
			exit('Database connection failed: '.mysqli_connect_error());
		}

		if (!$this->connect) 
		{
			return false;
		}

		return $this->select_db($db['name']);
	}

	public function select_db($name) 
	{
		if (!mysqli_select_db($this->connect, $name)) 
		{
			$this->error();
			exit('Could not select database.');
		}
		mysqli_query($this->connect, 'SET CHARACTER SET '.$this->charset.';');
		mysqli_query($this->connect, 'SET SESSION collation_connection="'.$this->charset.'_general_ci"');		
		mysqli_set_charset($this->connect, 'utf8');
		return true;
	}	

	/**
	* Replace Prefix for database queries.
	* This function was rewriten by MSDN in Apadana 1.1. This new version is 30 times
	* faster than the old one and with this one Apadana runs 30 percent faster than before!!!
	*
	* @since 1.0
	* @author MSDN
	*/
	protected function replace_prefix($sql, $prefix = '#__') 
	{
		$array = array();
		if($number = preg_match_all( '#((?<![\\\])[\'"])((?:.(?!(?<![\\\])\1))*.?)\1#i', $sql, $matches))
		{
			for ($i = 0; $i < $number; $i++)
			{
				if (!empty($matches[0][$i]))
				{
					$array[$i] = trim($matches[0][$i]);
					$sql = str_replace($matches[0][$i], '<#apadana_encode:'.$i.':code#>', $sql);
				}
			}
		}

		$sql = str_replace($prefix, $this->prefix , $sql);

	    foreach ($array as $key => $js)
	    {
			$sql = str_replace('<#apadana_encode:'.$key.':code#>', $js, $sql);
	    }

	    return $sql;
	}	

	public function query($string = null, $hide_errors = true, $prefix = '#__')
	{
		unset($this->result);

		if ($string != '')
		{
			$this->get_execution_time();
			
			$this->result = @mysqli_query($this->connect, $this->replace_prefix($string, $prefix));

			if ($this->error_number() && ($this->debug || !$hide_errors))
			{
				$this->error($string);
			}

			$query_time = $this->get_execution_time();

			if ($this->save_queries)
			{
				$this->queries[] = array(
					'query' => preg_replace('/([0-9a-f]){32}/', '********************************', $string), /* Hides all hashes */
					'result' => $this->result,
					'execution_time' => $query_time,
					'error_number' => $this->error_number(),
					'error_string' => $this->error_string()
				);
			}

			$this->query_time += $query_time;
			$this->num_queries++;
		}

		if ($this->result)
		{
			return $this->result;
		}

		return false;
	}

	public function fetch($query_id = false, $fetch = 'assoc', $set_query = false)
	{
		if (!($fetch == 'array' || $fetch == 'assoc' || $fetch == 'object' || $fetch == 'row'))
		{
			echo '<b>Fetch type must be one of: array, assoc, object, row</b>';
			return false;
		}

		$fetch = 'mysqli_fetch_'.$fetch;

		if (!$query_id)
		{
			$query_id = $this->result;
		}

		if ($set_query)
		{
			$query_id = $this->query($query_id);
		}

		if ($query_id)
		{
			return $fetch($query_id);
		}
		else
		{
			return false;
		}
	}

	public function get_row($query, $fetch = 'assoc', $index = false)
	{
		$this->query($query);

		if ($this->num_rows() <= 0)
		{
			return false;
		}

		$rows = array();
		while ($row = $this->fetch($this->result, $fetch))
		{
			if (!empty($index) && (isset($row->$index) || isset($row[$index])))
			{
				switch ($fetch)
				{
					case 'object':
					$rows[$row->$index] = $row;
					break;

					default:
					$rows[$row[$index]] = $row;
					break;
				}
			}
			else
			{
				$rows[] = $row;
			}
		}

		$this->free_result();
		return $rows;
	}

	public function insert($table, $array, $escape = true)
	{
		if (!is_array($array))
		{
			return false;
		}

		if ($escape)
		{
			$array = $this->escape_string($array);
		}

		$fields = '`'.implode('`,`', array_keys($array)).'`';
		$values = implode("','", $array);
		$this->query("
			INSERT
			INTO {$this->prefix}{$table} (".$fields.")
			VALUES ('".$values."')
		");

		return $this->insert_id();
	}

	public function update($table, $array, $where = null, $limit = null, $escape = true, $no_quote = false)
	{
		if (!is_array($array))
		{
			return false;
		}

		if ($escape)
		{
			$array = $this->escape_string($array);
		}

		$comma = null;
		$query = null;
		$quote = "'";

		if ($no_quote == true)
		{
			$quote = null;
		}

		foreach ($array as $field => $value)
		{
			$query .= $comma.'`'.$field."`={$quote}{$value}{$quote}";
			$comma = ', ';
		}

		if (!empty($where))
		{
			$query .= " WHERE {$where}";
		}

		if (!empty($limit))
		{
			$query .= " LIMIT {$limit}";
		}

		return $this->query("
			UPDATE {$this->prefix}{$table}
			SET {$query}
		");
	}

	public function delete($table, $where = null, $limit = null)
	{
		$query = null;

		if (!empty($where))
		{
			$query .= ' WHERE '.$where;
		}

		if (!empty($limit))
		{
			$query .= 'LIMIT '.$limit;
		}

		return $this->query("
			DELETE
			FROM {$this->prefix}{$table}
			{$query}
		");
	}

	public function num_rows($query_id = false, $set_query = false)
	{
		if (!$query_id)
		{
			$query_id = $this->result;
		}

		if ($set_query)
		{
			$query_id = $this->query($query_id);
		}

		if ($query_id)
		{
			return mysqli_num_rows($query_id);
		}
		else
		{
			return false;
		}
	}

	# this will be removed in the following version
	public function numRows($query_id = false, $set_query = false)
	{
		trigger_error('Function '.__CLASS__.'->'.__FUNCTION__.'() is deprecated', E_USER_DEPRECATED);

		return $this->num_rows($query_id, $set_query);
	}

	public function affected_rows()
	{
		if ($this->connect)
		{
			return mysqli_affected_rows($this->connect);
		}
		else
		{
			return false;
		}
	}

	# this will be removed in the following version
	public function affectedRows()
	{
		trigger_error('Function '.__CLASS__.'->'.__FUNCTION__.'() is deprecated', E_USER_DEPRECATED);

		return $this->affected_rows();
	}

	public function free_result($query_id = false)
	{
		if (!$query_id)
		{
			$query_id = $this->result;
		}
		if ($query_id && is_object($query_id))
		{
			try { return @mysqli_free_result($query_id); }
			catch (Throwable $e) { return false; }
		}
		return false;
	}

	# this will be removed in the following version
	public function freeResult($query_id = false)
	{
		trigger_error('Function '.__CLASS__.'->'.__FUNCTION__.'() is deprecated', E_USER_DEPRECATED);

		return $this->free_result($query_id);
	}

	public function insert_id()
	{
		if ($this->connect)
		{
			return mysqli_insert_id($this->connect);
		}
		else
		{
			return false;
		}
	}	

	# this will be removed in the following version
	public function insertID()
	{
		trigger_error('Function '.__CLASS__.'->'.__FUNCTION__.'() is deprecated', E_USER_DEPRECATED);

		return $this->insert_id();
	}

	public function escape_string($string)
	{
		if (is_array($string))
		{
			foreach ($string as $key => $str)
			{
				$string[$key] = $this->escape_string($str);
			}
		}
		elseif (is_object($string))
		{
			foreach ($string as $key => $str)
			{
				$string->{$key} = $this->escape_string($str);
			}
		}
		else
		{
			/*if (get_magic_quotes_gpc())
			{
				$string = stripslashes($string);
			}*/

			//check if this function exists
			if (function_exists('mysqli_real_escape_string') && $this->connect)
			{
				$string = mysqli_real_escape_string($this->connect, (string)$string);
			}
			else
			{
				$string = addslashes((string)$string);
			}
		}

		return $string;		
	}	

	# this will be removed in the following version
	public function escapeString($string)
	{
		trigger_error('Function '.__CLASS__.'->'.__FUNCTION__.'() is deprecated', E_USER_DEPRECATED);

		return $this->escape_string($string);
	}

	public function get_execution_time()
	{
		static $time_start;

		$time = microtime(true);

		// Just starting timer, init and return
		if (!$time_start)
		{
			$time_start = $time;
			return 0;
		}
		else # Timer has run, return execution time
		{
			$total = $time-$time_start;
			$time_start = 0;
			return $total < 0? 0 : $total;
		}
	}	

	public function error_number()
	{
		if ($this->connect)
		{
			return mysqli_errno($this->connect);
		}
	}

	public function error_string()
	{
		if ($this->connect)
		{
			return mysqli_error($this->connect);
		}
	}

	public function error($string = '')
	{
		if ($this->debug)
		{
			$string = trim($string);
			$string = explode("\n", $string);
			$string = array_map('trim', $string);
			$string = implode("\n", $string);
			echo("\n<!-- ERROR SQL! -->\n<div style='background:#FFCCCC;border:#FF6A6A 1px solid;padding:5px;margin:5px;direction:ltr;text-align:left'>\n<strong>[SQL] [".$this->error_number()."] ".$this->error_string()."</strong><br />\n<b>STRING:</b><pre style=\"direction:ltr;text-align:left;overflow-x:auto;\">{$string}</pre>\n</div>\n<!-- www.ApadanaCMS.ir -->\n\n");
		}
		else
		{
			return false;
		}
	}

	public function version() 
	{
		return preg_replace('/[^0-9.].*/', '', mysqli_get_server_info($this->connect));
	}

	public function __destruct()
	{
		return $this->close();
	}

	public function close()
	{
		try {
			if (isset($this->result) && is_object($this->result)) {
				@mysqli_free_result($this->result);
			}
		} catch (Throwable $e) {}
		$this->result = null;
		if ($this->connect && $this->mysqli)
		{
			$result = @mysqli_close($this->connect);
			$this->connect = false;
			return $result;
		}
		$this->connect = false;
		return false;
	}

	/** Prepared statement helpers for PHP 8 security */
	public function prepare_query($sql, $types = '', $params = array())
	{
		$sql = $this->replace_prefix($sql);
		if (!$this->mysqli || !is_object($this->connect))
		{
			return $this->query($sql);
		}
		$stmt = mysqli_prepare($this->connect, $sql);
		if (!$stmt)
		{
			$this->error($sql);
			return false;
		}
		if ($types !== '' && is_array($params) && count($params) > 0)
		{
			$refs = array();
			$bind = array($types);
			foreach ($params as $k => $v)
			{
				$refs[$k] = $params[$k];
				$bind[] = &$refs[$k];
			}
			call_user_func_array(array($stmt, 'bind_param'), $bind);
		}
		if (!mysqli_stmt_execute($stmt))
		{
			mysqli_stmt_close($stmt);
			$this->error($sql);
			return false;
		}
		$result = mysqli_stmt_get_result($stmt);
		if ($result !== false)
		{
			$this->result = $result;
			mysqli_stmt_close($stmt);
			return $result;
		}
		$affected = mysqli_stmt_affected_rows($stmt);
		mysqli_stmt_close($stmt);
		return $affected;
	}

	public function prepare_fetch($sql, $types = '', $params = array(), $fetch = 'assoc')
	{
		$res = $this->prepare_query($sql, $types, $params);
		if (!$res || !is_object($res)) return false;
		$row = ($fetch === 'row') ? mysqli_fetch_row($res) : mysqli_fetch_assoc($res);
		try { @mysqli_free_result($res); } catch (Throwable $e) {}
		return $row ? $row : false;
	}

	public function prepare_num_rows($sql, $types = '', $params = array())
	{
		$res = $this->prepare_query($sql, $types, $params);
		if (!$res || !is_object($res)) return 0;
		$n = mysqli_num_rows($res);
		try { @mysqli_free_result($res); } catch (Throwable $e) {}
		return (int) $n;
	}


}
