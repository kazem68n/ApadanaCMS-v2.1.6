/**
 * Apadana 2.1 — hardened CKEditor config
 */
CKEDITOR.editorConfig = function( config ) {
	config.language = 'fa';
	config.versionCheck = false;
	// Content Security: disallow script/iframe/object by default
	config.allowedContent = false;
	config.extraAllowedContent = 'a[!href]; img[!src,alt,width,height]; table[border,cellpadding,cellspacing,width]; tr; td[colspan,rowspan]; th; thead; tbody; ul; ol; li; p; br; strong; em; u; s; blockquote; pre; code; h1; h2; h3; h4; span[*]; div[*](*){*}';
	config.removePlugins = 'exportpdf,easyimage,cloudservices,forms,flash,iframe';
	config.disallowedContent = 'script; iframe; object; embed; form; input; button; link; meta; style; *[on*]';
	config.pasteFilter = 'semantic-content';
};
