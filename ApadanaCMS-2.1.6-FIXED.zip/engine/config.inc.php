<?php
defined("security") or exit;
define("database_type", "mysqli");
define("database_host", "localhost");
define("database_user", "x");
define("database_password", "x");
define("database_name", "x");
define("database_prefix", "ap_");
define("database_charset", "utf8");
define("database_cache", false);
define("debug_system", true);
define("domain", "mycms.hyperphp.com");
define("path", "/");
define("url", "https://mycms.hyperphp.com/");
