[not-ajax]
<script type="text/javascript">
var moduleDefault = '{default-module}';
var list_update = false;

function modules_ajax(id)
{
    if (id == 1)
	{
		if (!list_update)
		{
			return false;
		}
		apadana.ajax({
			type: 'GET',
			action: '{admin-page}&section=modules',
            loading: 'no',
			beforeSend: function()
			{
				apadana.html('option-id-1', '<p><center><img src="{site-url}engine/images/loading/loader-9.gif" width="54" height="55"></center></p>');
			},
			success: function(data)
			{
				list_update = false;
       			if (apadana.$('option-id-1').style.display=='block')
				{
					if (!apadana.browser.ie)
					apadana.fadeOut('option-id-1', function(){
						apadana.html('option-id-1', data);
						apadana.fadeIn('option-id-1');
					});
					else
					apadana.html('option-id-1', data);
				}
			}
		})
	}
	else if (id == 2)
	{
		apadana.html('modules-upload-process', '');
		apadana.$('modules-upload-form').reset();
		apadana.showID('modules-upload-form');
		$('#modules-progress-wrap').hide();
		$('#modules-upload-info').html('فایل زیپ ماژول را انتخاب کنید. پس از آپلود می‌توانید آن را نصب و فعال کنید.');
	}
}
function modules_default(name)
{
    if (!confirm("آیا از انتخاب این ماژول برای پیشفرض اطمینان دارید؟\n"+name)) return;
    apadana.ajax({
        type: 'GET',
        action: '{admin-page}&section=modules&do=default&name='+name,
        json: 'yes',
        success: function(data)
        {
            if (data.result == 'inactive')
            	alert('این ماژول غیرفعال است!');
            else if (data.result == 'error')
            	alert('خطایی رخ داده مجدد تلاش کنید');
            else if (data.result == 'success')
			{
    			apadana.changeSrc('modules-default-'+name, '{site-url}engine/images/icons/burn.png');
				apadana.attr('modules-default-'+name, 'onmouseover','tooltip.show(\'ماژول فعال در صفحه نخست سایت\')');
				
    			apadana.changeSrc('modules-default-'+moduleDefault, '{site-url}engine/images/icons/brightness-low.png');
				apadana.attr('modules-default-'+moduleDefault, 'onmouseover','tooltip.show(\'انتخاب برای فعال بودن در صفحه نخست\')');
				moduleDefault = name;
			}
        }
    });
}
function modules_active(name)
{
    if (!confirm("آیا از فعال/غیرفعال سازی این ماژول اطمینان دارید؟\n"+name)) return;
    apadana.ajax({
        type: 'GET',
        action: '{admin-page}&section=modules&do=active&name='+name,
        id: 'option-id-1',
    });
}
function modules_install(name)
{
    if (!confirm("آیا از نصب/حذف این ماژول اطمینان دارید؟\n"+name)) return;
    apadana.ajax({
        type: 'GET',
        action: '{admin-page}&section=modules&do=install&name='+name,
        id: 'option-id-1',
    });
}
function modules_upgrade(name)
{
    if (!confirm("آیا از بروزرسانی این ماژول اطمینان دارید؟\nممکن است کمی طول بکشد.\n"+name)) return;
    apadana.ajax({
        type: 'GET',
        action: '{admin-page}&section=modules&do=upgrade&name='+name,
        id: 'option-id-1',
    });
}
function modules_info(name)
{
    apadana.ajax({
		method: 'get',
		action: '{admin-page}&section=modules&do=get_info&name='+name,
		json : 'yes' ,
		success: function(data)
		{
			if (data.result == 'success')
			{
				$('#infobox').html(data.info);
				apadana.infoBox('#infobox',1,1);
			}
			else
			{
				alert(data.message);
			}
		}
	});
}

function modules_formatBytes(bytes) {
	if (bytes === 0) return '0 بایت';
	var k = 1024, sizes = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'];
	var i = Math.floor(Math.log(bytes) / Math.log(k));
	return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function modules_startUpload(e)
{
	if (e) e.preventDefault();
	var fileInput = document.getElementById('modules-file-input');
	if (!fileInput || !fileInput.files || !fileInput.files.length) {
		alert('لطفا یک فایل زیپ انتخاب کنید.');
		return false;
	}
	var file = fileInput.files[0];
	if (!/\.zip$/i.test(file.name)) {
		alert('فقط فایل زیپ مجاز است!');
		return false;
	}

	list_update = true;
	apadana.hideID('modules-upload-form');
	$('#modules-progress-wrap').show();
	$('#modules-progress-bar').css('width', '0%').text('0%');
	$('#modules-upload-info').html('در حال آماده‌سازی آپلود...');
	$('#modules-progress-detail').html(
		'حجم کل: <b>' + modules_formatBytes(file.size) + '</b> &nbsp;|&nbsp; ' +
		'آپلود شده: <b>0</b> &nbsp;|&nbsp; ' +
		'باقیمانده: <b>' + modules_formatBytes(file.size) + '</b>'
	);

	var formData = new FormData();
	formData.append('myfile', file);

	var xhr = new XMLHttpRequest();
	xhr.open('POST', '{admin-page}&section=modules&do=upload', true);

	xhr.upload.onprogress = function(ev) {
		if (ev.lengthComputable) {
			var percent = Math.round((ev.loaded / ev.total) * 100);
			var remaining = ev.total - ev.loaded;
			$('#modules-progress-bar').css('width', percent + '%').text(percent + '%');
			$('#modules-upload-info').html(percent < 100 ? 'در حال آپلود فایل...' : 'در حال پردازش و استخراج فایل زیپ...');
			$('#modules-progress-detail').html(
				'حجم کل: <b>' + modules_formatBytes(ev.total) + '</b> &nbsp;|&nbsp; ' +
				'آپلود شده: <b>' + modules_formatBytes(ev.loaded) + '</b> &nbsp;|&nbsp; ' +
				'باقیمانده: <b>' + modules_formatBytes(remaining) + '</b> &nbsp;|&nbsp; ' +
				'<span style="color:#1a7f37">' + percent + '%</span>'
			);
		}
	};

	xhr.onload = function() {
		list_update = true;
		var result = xhr.responseText || '';
		result = result.replace(/<script[\s\S]*?<\/script>/gi, '').trim();
		if (xhr.status >= 200 && xhr.status < 300) {
			apadana.html('modules-upload-process', result);
		} else {
			apadana.html('modules-upload-process', '<font color=red>خطا در ارتباط با سرور (کد ' + xhr.status + ')</font>');
		}
		apadana.$('modules-upload-form').reset();
		apadana.showID('modules-upload-form');
		$('#modules-progress-wrap').hide();
		$('#modules-progress-bar').css('width', '0%').text('0%');
	};

	xhr.onerror = function() {
		list_update = true;
		apadana.html('modules-upload-process', '<font color=red>خطا در ارسال فایل. اتصال اینترنت یا سرور را بررسی کنید.</font>');
		apadana.showID('modules-upload-form');
		$('#modules-progress-wrap').hide();
	};

	xhr.send(formData);
	return false;
}

function modules_stopUpload(result)
{
	list_update = true;
	apadana.html('modules-upload-process', result+'<br><br>');
	apadana.$('modules-upload-form').reset();
	apadana.showID('modules-upload-form');
	$('#modules-progress-wrap').hide();
}
</script>

<style>
#modules-progress-wrap {
	margin: 20px auto;
	max-width: 520px;
	text-align: right;
	direction: rtl;
}
#modules-progress-bar-bg {
	background: #e8e8e8;
	border-radius: 8px;
	height: 28px;
	overflow: hidden;
	border: 1px solid #ccc;
	box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
}
#modules-progress-bar {
	background: linear-gradient(90deg, #1976d2, #0d47a1);
	height: 100%;
	width: 0%;
	color: #fff;
	font-weight: bold;
	font-size: 13px;
	line-height: 28px;
	text-align: center;
	transition: width 0.15s ease;
	border-radius: 7px;
	min-width: 2em;
}
#modules-progress-detail {
	margin-top: 10px;
	font-size: 13px;
	color: #444;
	line-height: 1.7;
}
#modules-upload-info {
	margin-bottom: 12px;
	font-size: 13px;
	color: #333;
}
.modules-upload-box {
	background: #f9f9f9;
	border: 1px solid #ddd;
	border-radius: 8px;
	padding: 25px 20px;
	max-width: 520px;
	margin: 0 auto;
	box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.modules-upload-box label {
	display: block;
	margin: 12px 0;
}
.modules-upload-box input[type="file"] {
	padding: 6px;
	border: 1px solid #ccc;
	border-radius: 4px;
	width: 100%;
	max-width: 100%;
	box-sizing: border-box;
}
.modules-upload-box input[type="submit"],
.modules-upload-box button {
	background: #1565c0;
	color: #fff;
	border: none;
	padding: 10px 28px;
	border-radius: 5px;
	cursor: pointer;
	font-size: 14px;
	margin-top: 8px;
}
.modules-upload-box input[type="submit"]:hover,
.modules-upload-box button:hover {
	background: #0d47a1;
}
</style>

<div id="infobox" style="display:none">
</div>

<!-- TAB START-->
<div class="content">
<div class="content-tabs">
<ul>
  <li class="tab-on" id="tab-id-1" onclick="apadana.changeTab(1, 2, function(){modules_ajax(1)})">فهرست ماژول ها</li>
  <li class="tab-off" id="tab-id-2" onclick="apadana.changeTab(2, 2, function(){modules_ajax(2)})">نصب ماژول</li>
</ul>
</div>
<div class="content-main">
<div class="content-space">

<div id="option-id-1">
[/not-ajax]
<table class="apadana-table" cellpadding="0" cellspacing="0">
<thead>
  <tr>
	<th align="right">نام ماژول</th>
	<th data-tooltip="سلام" width="50">اطلاعات</th>
	<th width="50">وضعیت</th>
	<th width="50">پیشفرض</th>
	<th width="50">فعال</th>
	<th width="50">نصب</th>
	<th width="50">بروزرسانی</th>
  </tr>
</thead>
<tbody>
[for modules]
  <tr class="{odd-even}">
	<td dir="rtl" align="right">{show-name}</td>
	<td><a href="javascript:modules_info('{name}')"><img src="{site-url}engine/images/icons/external.png" width="16" height="16" data-tooltip="اطلاعات ماژول" ></a></td>
	<td><img src="{site-url}engine/images/icons/[status][compatibility]tick-button[/compatibility][not-compatibility]question-button[/not-compatibility][/status][not-status]exclamation-button[/not-status].png" data-tooltip="[status]این ماژول سالم است[compatibility] و با نسخه آپادانای شما سازگار است[/compatibility][not-compatibility] ولی با نسخه آپادانای شما سازگار نیست[/not-compatibility][/status][not-status]این ماژول ناقص است[/not-status]" ></td>
	<td><a href="javascript:modules_default('{name}')"><img id="modules-default-{name}" src="{site-url}engine/images/icons/[default]burn[/default][not-default][install]brightness-low[/install][not-install]puzzle--exclamation[/not-install][/not-default].png" data-tooltip="[default]ماژول فعال در صفحه نخست سایت[/default][not-default][status][install]انتخاب برای فعال بودن در صفحه نخست[/install][not-install]ماژول نصب نشده است[/not-install][/status][not-status]این ماژول ناقص است[/not-status][/not-default]" ></a></td>
	<td><a href="javascript:modules_active('{name}')"><img src="{site-url}engine/images/icons/[active]flag-green[/active][not-active]flag-pink[/not-active].png" data-tooltip="[active]غیرفعال کردن[/active][not-active]فعال کردن[/not-active]" ></a></td>
	<td><a href="javascript:modules_install('{name}')"><img src="{site-url}engine/images/icons/[status][install]puzzle--minus[/install][not-install]plus-button[/not-install][/status][not-status]exclamation-button[/not-status].png" data-tooltip="[status][install]حذف کردن[/install][not-install]نصب کردن[/not-install][/status][not-status]این ماژول ناقص است[/not-status]" ></a></td>
	<td><a href="javascript:modules_upgrade('{name}')"><img src="{site-url}engine/images/icons/[status][upgrade]puzzle--arrow[/upgrade][not-upgrade]slash-button[/not-upgrade][/status][not-status]exclamation-button[/not-status].png" data-tooltip="[status][upgrade]دارای بروزرسانی[/upgrade][not-upgrade]نیازی به بروزرسانی ندارد[/not-upgrade][/status][not-status]این ماژول ناقص است[/not-status]" ></a></td>
  </tr>
[/for modules]
</tbody>
</table>

[not-ajax]
</div>
<!-- /option-id-1 -->
<div id="option-id-2" style="display:none;text-align:center;padding:30px 15px">

<div id="modules-upload-process" style="margin-bottom:15px"></div>

<div id="modules-progress-wrap" style="display:none">
	<div id="modules-upload-info">در حال آپلود...</div>
	<div id="modules-progress-bar-bg">
		<div id="modules-progress-bar">0%</div>
	</div>
	<div id="modules-progress-detail"></div>
</div>

<div class="modules-upload-box" id="modules-upload-form-wrap">
<form id="modules-upload-form" action="{admin-page}&section=modules&do=upload" method="post" enctype="multipart/form-data" onsubmit="return modules_startUpload(event);">
	<label style="font-weight:bold;margin-bottom:8px">انتخاب فایل زیپ ماژول:</label>
	<input id="modules-file-input" name="myfile" type="file" accept=".zip,application/zip" />
	<button type="submit">آپلود و نصب ماژول</button>
</form>
<p style="margin-top:15px;font-size:12px;color:#666">فقط فایل‌های با پسوند .zip پذیرفته می‌شوند.</p>
</div>

</div>
<!-- /option-id-2 -->

<div class="clear"></div>
</div>
</div>
<div class="content-bottom"></div>
</div>
<!-- TAB END-->
[/not-ajax]
