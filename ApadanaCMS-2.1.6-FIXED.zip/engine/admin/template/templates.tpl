[not-ajax]
<script type="text/javascript">
var themeDefault = '{theme}';
var list_update = false;

function templates_ajax(id)
{
    if(id == 1)
	{
		if (!list_update)
		{
			return false;
		}
		apadana.ajax({
			type: 'GET',
			action: '{admin-page}&section=templates',
            loading: 'no',
			beforeSend: function()
			{
				list_update = false;
				apadana.html('option-id-1', '<p><center><img src="{site-url}engine/images/loading/loader-9.gif" width="54" height="55"></center></p>');
			},
			success: function(data)
			{
        		if(apadana.$('option-id-1').style.display=='block')
				{
					$('#option-id-1').fadeOut('slow', function(){
						$('#option-id-1').html(data).fadeIn('slow')
					})
				}
			}
		})
	}
	else if(id == 2)
	{
		apadana.html('templates-upload-process', '');
		apadana.$('templates-upload-form').reset();
		apadana.showID('templates-upload-form');
		$('#templates-progress-wrap').hide();
		$('#templates-upload-info').html('فایل زیپ تم را انتخاب کنید. پس از آپلود می‌توانید آن را فعال کنید.');
	}
}
function templates_default(name)
{
    if(!confirm('آیا از این کار اطمینان دارید؟')) return;
    apadana.ajax({
        type: 'GET',
        action: '{admin-page}&section=templates&do=default&name='+name,
        json: 'yes',
        success: function(data)
        {
            if(data.result == 'status')
            	alert('تم ناقص است!');
            else if(data.result == 'error')
            	alert('خطایی رخ داده مجدد تلاش کنید');
            else if(data.result == 'success')
			{
    			apadana.changeSrc('templates-default-'+name, 'engine/images/icons/burn.png');
				apadana.attr('templates-default-'+name, 'data-tooltip','tooltip.show(\'تم سایت\')');
				
    			apadana.changeSrc('templates-default-'+themeDefault, 'engine/images/icons/brightness-low.png');
				apadana.attr('templates-default-'+themeDefault, 'data-tooltip','tooltip.show(\'انتخاب برای تم سایت\')');
				themeDefault = name;
			}
        }
    });
}
function templates_info(name)
{
    apadana.ajax({
		method: 'get',
		action: '{admin-page}&section=templates&do=get_info&name='+name,
		json : 'yes' ,
		success: function(data)
		{
			if (data.result == 'success')
			{
				$('#templates-info-box').html(data.info);
				apadana.infoBox('#templates-info-box',1,1);
			}
			else
			{
				alert(data.message);
			}
		}
	});
}

function templates_formatBytes(bytes) {
	if (bytes === 0) return '0 بایت';
	var k = 1024, sizes = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'];
	var i = Math.floor(Math.log(bytes) / Math.log(k));
	return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function templates_startUpload(e)
{
	if (e) e.preventDefault();
	var fileInput = document.getElementById('templates-file-input');
	if (!fileInput || !fileInput.files || !fileInput.files.length) {
		alert('لطفا یک فایل زیپ انتخاب کنید.');
		return false;
	}
	var file = fileInput.files[0];
	if (!/\.zip$/i.test(file.name)) {
		alert('فقط فایل زیپ مجاز است!');
		return false;
	}

	list_update = true;
	apadana.hideID('templates-upload-form');
	$('#templates-progress-wrap').show();
	$('#templates-progress-bar').css('width', '0%').text('0%');
	$('#templates-upload-info').html('در حال آماده‌سازی آپلود...');
	$('#templates-progress-detail').html(
		'حجم کل: <b>' + templates_formatBytes(file.size) + '</b> &nbsp;|&nbsp; ' +
		'آپلود شده: <b>0</b> &nbsp;|&nbsp; ' +
		'باقیمانده: <b>' + templates_formatBytes(file.size) + '</b>'
	);

	var formData = new FormData();
	formData.append('myfile', file);

	var xhr = new XMLHttpRequest();
	xhr.open('POST', '{admin-page}&section=templates&do=upload', true);

	xhr.upload.onprogress = function(ev) {
		if (ev.lengthComputable) {
			var percent = Math.round((ev.loaded / ev.total) * 100);
			var remaining = ev.total - ev.loaded;
			$('#templates-progress-bar').css('width', percent + '%').text(percent + '%');
			$('#templates-upload-info').html(percent < 100 ? 'در حال آپلود فایل...' : 'در حال پردازش و استخراج فایل زیپ...');
			$('#templates-progress-detail').html(
				'حجم کل: <b>' + templates_formatBytes(ev.total) + '</b> &nbsp;|&nbsp; ' +
				'آپلود شده: <b>' + templates_formatBytes(ev.loaded) + '</b> &nbsp;|&nbsp; ' +
				'باقیمانده: <b>' + templates_formatBytes(remaining) + '</b> &nbsp;|&nbsp; ' +
				'<span style="color:#1a7f37">' + percent + '%</span>'
			);
		}
	};

	xhr.onload = function() {
		list_update = true;
		var result = xhr.responseText || '';
		// Clean possible script tags from old responses for safety
		result = result.replace(/<script[\s\S]*?<\/script>/gi, '').trim();
		if (xhr.status >= 200 && xhr.status < 300) {
			apadana.html('templates-upload-process', result);
		} else {
			apadana.html('templates-upload-process', '<font color=red>خطا در ارتباط با سرور (کد ' + xhr.status + ')</font>');
		}
		apadana.$('templates-upload-form').reset();
		apadana.showID('templates-upload-form');
		$('#templates-progress-wrap').hide();
		$('#templates-progress-bar').css('width', '0%').text('0%');
	};

	xhr.onerror = function() {
		list_update = true;
		apadana.html('templates-upload-process', '<font color=red>خطا در ارسال فایل. اتصال اینترنت یا سرور را بررسی کنید.</font>');
		apadana.showID('templates-upload-form');
		$('#templates-progress-wrap').hide();
	};

	xhr.send(formData);
	return false;
}

// Keep for backward compatibility if old iframe somehow used
function templates_stopUpload(result)
{
	list_update = true;
	apadana.html('templates-upload-process', result+'<br><br>');
	apadana.$('templates-upload-form').reset();
	apadana.showID('templates-upload-form');
	$('#templates-progress-wrap').hide();
}
</script>

<style>
#templates-progress-wrap {
	margin: 20px auto;
	max-width: 520px;
	text-align: right;
	direction: rtl;
}
#templates-progress-bar-bg {
	background: #e8e8e8;
	border-radius: 8px;
	height: 28px;
	overflow: hidden;
	border: 1px solid #ccc;
	box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
}
#templates-progress-bar {
	background: linear-gradient(90deg, #4caf50, #2e7d32);
	height: 100%;
	width: 0%;
	color: #fff;
	font-weight: bold;
	font-size: 13px;
	line-height: 28px;
	text-align: center;
	transition: width 0.15s ease;
	border-radius: 7px;
	min-width: 2em;
}
#templates-progress-detail {
	margin-top: 10px;
	font-size: 13px;
	color: #444;
	line-height: 1.7;
}
#templates-upload-info {
	margin-bottom: 12px;
	font-size: 13px;
	color: #333;
}
.templates-upload-box {
	background: #f9f9f9;
	border: 1px solid #ddd;
	border-radius: 8px;
	padding: 25px 20px;
	max-width: 520px;
	margin: 0 auto;
	box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.templates-upload-box label {
	display: block;
	margin: 12px 0;
}
.templates-upload-box input[type="file"] {
	padding: 6px;
	border: 1px solid #ccc;
	border-radius: 4px;
	width: 100%;
	max-width: 100%;
	box-sizing: border-box;
}
.templates-upload-box input[type="submit"],
.templates-upload-box button {
	background: #2e7d32;
	color: #fff;
	border: none;
	padding: 10px 28px;
	border-radius: 5px;
	cursor: pointer;
	font-size: 14px;
	margin-top: 8px;
}
.templates-upload-box input[type="submit"]:hover,
.templates-upload-box button:hover {
	background: #1b5e20;
}
</style>

<div id="templates-info-box" style="display:none">
</div>

<!-- TAB START-->
<div class="content">
<div class="content-tabs">
<ul>
  <li class="tab-on" id="tab-id-1" onclick="apadana.changeTab(1, 2, function(){templates_ajax(1)})">فهرست تم ها</li>
  <li class="tab-off" id="tab-id-2" onclick="apadana.changeTab(2, 2, function(){templates_ajax(2)})">نصب تم</li>
</ul>
</div>
<div class="content-main">
<div class="content-space">

<div id="option-id-1">
[/not-ajax]
<table class="apadana-table" cellpadding="0" cellspacing="0">
<thead>
  <tr>
	<th align="right">نام تم</th>
	<th width="50">اطلاعات</th>
	<th width="50">وضعیت</th>
	<th width="50">پیشفرض</th>
	<th width="50">ویرایش</th>
  </tr>
</thead>
<tbody>
[for templates]
  <tr class="{odd-even}">
	<td align="right">{show-name}</td>
	<td><a href="javascript:templates_info('{name}')"><img src="{site-url}engine/images/icons/external.png" width="16" height="16" data-tooltip="اطلاعات تم" ></a></td>
	<td><img src="{site-url}engine/images/icons/[status][compatibility]tick-button[/compatibility][not-compatibility]question-button[/not-compatibility][/status][not-status]exclamation-button[/not-status].png" data-tooltip="[status]این تم سالم است[compatibility] و با نسخه آپادانای شما سازگار است[/compatibility][not-compatibility] ولی با نسخه آپادانای شما سازگار نیست[/not-compatibility][/status][not-status]این تم ناقص است[/not-status]" ></td>
	<td><a href="javascript:templates_default('{name}')"><img id="templates-default-{name}" src="{site-url}engine/images/icons/[default]burn[/default][not-default][status]brightness-low[/status][not-status]slash-button[/not-status][/not-default].png" data-tooltip="[default]تم سایت[/default][not-default][status]انتخاب برای تم سایت[/status][not-status]این تم ناقص است[/not-status][/not-default]" ></a></td>
	<td><a href="{admin-page}&section=templates&do=edit&name={name}"><img src="{site-url}engine/images/icons/document-edit-icon.png" data-tooltip="ویرایش تم" ></a></td>
  </tr>
[/for templates]
</tbody>
</table>

[not-ajax]
</div>
<!-- /option-id-1 -->
<div id="option-id-2" style="display:none;text-align:center;padding:30px 15px">

<div id="templates-upload-process" style="margin-bottom:15px"></div>

<div id="templates-progress-wrap" style="display:none">
	<div id="templates-upload-info">در حال آپلود...</div>
	<div id="templates-progress-bar-bg">
		<div id="templates-progress-bar">0%</div>
	</div>
	<div id="templates-progress-detail"></div>
</div>

<div class="templates-upload-box" id="templates-upload-form-wrap">
<form id="templates-upload-form" action="{admin-page}&section=templates&do=upload" method="post" enctype="multipart/form-data" onsubmit="return templates_startUpload(event);">
	<label style="font-weight:bold;margin-bottom:8px">انتخاب فایل زیپ تم:</label>
	<input id="templates-file-input" name="myfile" type="file" accept=".zip,application/zip" />
	<button type="submit">آپلود و نصب تم</button>
</form>
<p style="margin-top:15px;font-size:12px;color:#666">فقط فایل‌های با پسوند .zip پذیرفته می‌شوند.</p>
</div>

</div>
<!-- /option-id-2 -->

<div class="clear"></div>
</div>
</div>
<div class="content-bottom"></div>
</div>
<!-- TAB END-->
[/not-ajax]
