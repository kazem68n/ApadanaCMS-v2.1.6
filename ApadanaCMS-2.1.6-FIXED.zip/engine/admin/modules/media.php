<?php
/**
 * Secure Media Manager (replaces elFinder)
 * Restricts access to uploads/ only, whitelist extensions.
 */
defined('security') or exit('Direct Access to this location is not allowed.');
member::check_admin_page_access('media') or warning('عدم دسترسی!', 'شما دسترسی لازم را ندارید!');

function media_allowed_ext()
{
	return array('jpg','jpeg','png','gif','webp','svg','pdf','zip','rar','7z','doc','docx','xls','xlsx','ppt','pptx','mp3','mp4','txt','csv');
}

function media_uploads_root()
{
	$dir = root_dir.'uploads/';
	if (!is_dir($dir)) @mkdir($dir, 0755, true);
	return realpath($dir) ?: $dir;
}

function media_safe_path($rel)
{
	$root = media_uploads_root();
	$rel = str_replace(array('..', '\\'), array('', '/'), (string)$rel);
	$rel = ltrim($rel, '/');
	$full = realpath($root.'/'.$rel);
	if ($full === false)
	{
		# may not exist yet for mkdir
		$full = $root.'/'.$rel;
	}
	$rootR = realpath($root);
	if (strpos(str_replace('\\','/',$full), str_replace('\\','/',$rootR)) !== 0)
		return false;
	return $full;
}

$do = get_param($_GET, 'do');
if ($do === 'upload' && $_SERVER['REQUEST_METHOD'] === 'POST')
{
	header('Content-Type: application/json; charset=utf-8');
	if (function_exists('csrf_check')) csrf_check(null, false);
	$subdir = get_param($_POST, 'dir', '');
	$targetDir = media_safe_path($subdir);
	if ($targetDir === false || (!is_dir($targetDir) && !@mkdir($targetDir, 0755, true)))
	{
		echo json_encode(array('ok'=>false,'error'=>'مسیر نامعتبر'));
		exit;
	}
	if (empty($_FILES['file']['tmp_name']))
	{
		echo json_encode(array('ok'=>false,'error'=>'فایلی ارسال نشد'));
		exit;
	}
	$ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
	if (!in_array($ext, media_allowed_ext(), true))
	{
		echo json_encode(array('ok'=>false,'error'=>'پسوند مجاز نیست'));
		exit;
	}
	$base = preg_replace('/[^a-zA-Z0-9._-]/', '_', pathinfo($_FILES['file']['name'], PATHINFO_FILENAME));
	$name = date('Ymd_His').'_'.$base.'.'.$ext;
	if (!move_uploaded_file($_FILES['file']['tmp_name'], rtrim($targetDir,'/\\').'/'.$name))
	{
		echo json_encode(array('ok'=>false,'error'=>'آپلود ناموفق'));
		exit;
	}
	$rel = trim($subdir.'/'.$name, '/');
	echo json_encode(array('ok'=>true,'path'=>'uploads/'.$rel,'url'=>url.'uploads/'.$rel));
	exit;
}

if ($do === 'delete')
{
	$name = get_param($_GET, 'file', '');
	$path = media_safe_path($name);
	if ($path && is_file($path) && basename($path) !== 'index.html' && basename($path) !== '.htaccess')
	{
		@unlink($path);
		echo message('حذف شد.', 'success');
	}
	else echo message('فایل نامعتبر.', 'error');
	if (is_ajax()) { define('no_template', true); exit; }
}

# list
set_title('رسانه');
$subdir = get_param($_GET, 'dir', '');
$dir = media_safe_path($subdir);
if ($dir === false || !is_dir($dir)) $dir = media_uploads_root();

$html = '<div class="content"><div class="content-title">مدیریت رسانه (امن)</div><div class="content-main"><div class="content-space">';
$html .= '<p><b>پوشه:</b> uploads/'.htmlspecialchars($subdir, ENT_QUOTES, 'UTF-8').'</p>';
$html .= '<form method="post" action="'.admin_page.'&section=media&do=upload" enctype="multipart/form-data" onsubmit="return mediaUpload(this)">';
if (function_exists('csrf_field')) $html .= csrf_field();
$html .= '<input type="hidden" name="dir" value="'.htmlspecialchars($subdir, ENT_QUOTES, 'UTF-8').'">';
$html .= '<input type="file" name="file" required> <button type="submit">آپلود</button>';
$html .= ' <small>مجاز: '.htmlspecialchars(implode(', ', media_allowed_ext()), ENT_QUOTES, 'UTF-8').'</small></form>';
$html .= '<div id="media-msg"></div><hr>';
$html .= '<table class="apadana-table" width="100%"><tr><th align="right">نام</th><th>حجم</th><th></th></tr>';
$dh = @opendir($dir);
$items = array();
if ($dh)
{
	while (($f = readdir($dh)) !== false)
	{
		if ($f==='.'||$f==='..') continue;
		$items[] = $f;
	}
	closedir($dh);
}
sort($items);
foreach ($items as $f)
{
	$fp = rtrim($dir,'/\\').'/'.$f;
	$rel = trim($subdir.'/'.$f, '/');
	if (is_dir($fp))
	{
		$html .= '<tr><td align="right"><a href="'.admin_page.'&section=media&dir='.rawurlencode($rel).'">📁 '.htmlspecialchars($f, ENT_QUOTES, 'UTF-8').'</a></td><td>—</td><td></td></tr>';
	}
	else
	{
		$size = @filesize($fp);
		$url = url.'uploads/'.$rel;
		$html .= '<tr><td align="right" dir="ltr" style="text-align:left"><a href="'.htmlspecialchars($url, ENT_QUOTES, 'UTF-8').'" target="_blank">'.htmlspecialchars($f, ENT_QUOTES, 'UTF-8').'</a></td>';
		$html .= '<td>'.round($size/1024,1).' KB</td>';
		$html .= '<td><a href="'.admin_page.'&section=media&do=delete&file='.rawurlencode($rel).'" onclick="return confirm(\'حذف؟\')">حذف</a></td></tr>';
	}
}
$html .= '</table></div></div><div class="content-bottom"></div></div>';
$html .= '<script>function mediaUpload(f){var fd=new FormData(f);var x=new XMLHttpRequest();x.open("POST",f.action);x.onload=function(){try{var r=JSON.parse(x.responseText);document.getElementById("media-msg").innerHTML=r.ok?"آپلود شد: "+r.path: (r.error||"خطا");if(r.ok)setTimeout(function(){location.reload()},600);}catch(e){}};x.send(fd);return false;}</script>';

global $tpl;
$tpl->assign('{content}', $html);
