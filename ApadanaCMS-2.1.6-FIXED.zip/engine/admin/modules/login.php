<?php
/**
 * @In the name of God!
 * Admin login — prepared statements + password_hash (Apadana 2.1)
 */
defined('security') or exit('Direct Access to this location is not allowed.');

if (member == 1 && group_admin == 1)
{
	redirect(admin_page);
}

function _index()
{
	global $options, $page, $d, $tpl;

	if (is_ajax())
	{
		exit('<font color=red>دوره ی مدیریتی شما پایان یافته لطفا مجدد وارد سیستم شوید!<font>');
	}

	$tpl->load('login.tpl');
	$tpl->assign(array(
		'{redirect}' => nohtml(current_url()),
	));
}

function _save()
{
	global $d;

	$r = 'no';
	$url = admin_page;
	$login = get_param($_POST, 'login');

	if (isset($login) && is_array($login) && count($login) && isset($login['username']) && isset($login['password']))
	{
		$login['username'] = apadana_strtolower(trim($login['username']));

		$result = $d->prepare_fetch(
			"SELECT * FROM #__members WHERE member_status='1' AND member_group!='4' AND member_name=? LIMIT 1",
			's',
			array($login['username'])
		);

		if (is_alphabet($login['username']) && is_array($result) && count($result) && !empty($result['member_password']))
		{
			if (function_exists('login_rate_limit') && !login_rate_limit())
			{
				exit('{"result":"no","url":"'.$url.'","error":"rate"}');
			}

			if (member::check_password($login['password'], $result['member_password']))
			{
				if (strpos((string)$result['member_password'], '$2y$') !== 0 && strpos((string)$result['member_password'], '$argon') !== 0)
				{
					$newHash = member::password($login['password']);
					$d->update('members', array('member_password' => $newHash), "member_id='".intval($result['member_id'])."'", 1);
					$result['member_password'] = $newHash;
				}
				if (function_exists('login_rate_limit_clear')) login_rate_limit_clear();

				$loginKey = member::loginKey($result['member_password']);
				set_cookie('account', base64_encode($result['member_id'].'::'.md5($loginKey)));

				$d->update('members', array(
					'member_key' => $loginKey,
					'member_lastvisit' => time(),
					'member_visits' => $result['member_visits']+1,
					'member_lastip' => get_ip(),
				), "member_id='".intval($result['member_id'])."'", 1);

				$r = 'yes';

				if (isset($login['redirect']) && validate_url($login['redirect']) && stristr($login['redirect'], domain))
				{
					$url = nohtml($login['redirect']);
				}
			}
			else
			{
				if (function_exists('login_rate_limit_hit')) login_rate_limit_hit();
			}
		}
	}

	exit('{"result":"'.$r.'","url":"'.$url.'"}');
}

if (isset($_POST['login']) && is_array($_POST['login']))
	_save();
else
	_index();

?>
