<?php
/**
 * @In the name of God!
 * @author: Iman Moodi (Iman92)
 * @email: info@apadanacms.ir
 * @link: http://www.apadanacms.ir
 * @license: http://www.gnu.org/licenses/
 * @copyright: Copyright © 2012-2015 ApadanaCms.ir. All rights reserved.
 * @Apadana CMS is a Free Software
 */

defined('security') or exit('Direct Access to this location is not allowed.');

member::check_admin_page_access('templates') or warning('عدم دسترسی!', 'شما دسترسی لازم برای مشاهده این بخش را ندارید!');

function _index()
{
	global $tpl, $options, $d;
	set_title('تم ها');

	$itpl = new template('engine/admin/template/templates.tpl');
	
	$handle = opendir(root_dir.'templates');
	while($dir = readdir($handle))
	{
		if (!is_dir(root_dir.'templates/'.$dir) || $dir == '.' || $dir == '..') continue;
		
		$info = array(
			'name' => $dir,
			'version' => '1.0',
			'compatibility' => '*',
			'creation-date' => date('Y-m-d H:i:s', file_exists(root_dir.'templates/'.$dir.'/body.html')? filemtime(root_dir.'templates/'.$dir.'/body.html') : time()),
			'description' => null,
			'author' => null,
			'author-email' => null,
			'author-url' => null,
			'screenshot' => null,
			'positions' => null,
			'pages' => null,
			'html-compression' => 0,
			'license' => 'GNU/GPL',
		);
		
		if (template_exists($dir))
		{
			$info = template_info($dir);
			$info['screenshot'] = nohtml($info['screenshot']);
		}

		$itpl->add_for('templates', array(
			'{odd-even}' => odd_even(),
			'{name}' => $dir,
			'{show-name}' => (apadana_strtolower($info['name']) != apadana_strtolower($dir)? $info['name'].' <span style="visibility:hidden;font-size:2px">z</span><span style="color:#487d8c;font-size:10px">('.$dir.')</span><span style="visibility:hidden;font-size:2px">z</span>' : $dir),
/*			'{info-version}' => $info['version'],
			'{info-compatibility}' => $info['compatibility'],
			'{info-creation-date}' => jdate('l j F Y ساعت g:i A', strtotime($info['creation-date'])),
			'{info-description}' => empty($info['description'])? 'بدون توضیح' : $info['description'],
			'{info-screenshot}' => empty($info['screenshot']) || !file_exists(root_dir.'templates/'.$dir.'/'.$info['screenshot'])? url.'engine/images/screenshots.png' : url.'templates/'.$dir.'/'.$info['screenshot'],
			'{info-author}' => empty($info['author'])? 'ناشناخته' : htmlencode($info['author']),
			'{info-author-email}' => !validate_email($info['author-email'])? 'ناشناخته' : nohtml($info['author-email']),
			'{info-author-url}' => empty($info['author-url']) || !validate_url($info['author-url'])? 'unknown' : nohtml($info['author-url']),
			'{info-positions}' => empty($info['positions'])? 'ناشناخته' : nohtml($info['positions']),
			'{info-pages}' => empty($info['pages'])? 'ناشناخته' : nohtml($info['pages']),
			'{info-html-compression}' => $info['html-compression']? 'فعال' : 'غیرفعال',
			'{info-license}' => empty($info['license'])? 'GNU/GPL' : nohtml($info['license']),*/
			
			'replace' => array(
				'#\\[status\\](.*?)\\[/status\\]#s' => template_exists($dir)? '\\1' : '',
				'#\\[not-status\\](.*?)\\[/not-status\\]#s' => !template_exists($dir)? '\\1' : '',
				'#\\[compatibility\\](.*?)\\[/compatibility\\]#s' => apadana_compare($info['compatibility'])? '\\1' : '',
				'#\\[not-compatibility\\](.*?)\\[/not-compatibility\\]#s' => !apadana_compare($info['compatibility'])? '\\1' : '',
				'#\\[default\\](.*?)\\[/default\\]#s' => $options['theme']==$dir? '\\1' : '',
				'#\\[not-default\\](.*?)\\[/not-default\\]#s' => $options['theme']!=$dir? '\\1' : '',
			)
		));
	}
	closedir($handle);
	unset($handle, $dir);

	$itpl->assign(array(
		'{theme}' => $options['theme'],
	));
	
	if (is_ajax())
	{
		define('no_template', true);
		$itpl->display();
	}
	else
	{
		$tpl->assign('{content}', $itpl->get_var());
	}
	unset($itpl);
}

function _default()
{
	global $tpl, $options, $page, $d;
	$result = 'status';
	$name = get_param($_GET, 'name');
	$name = alphabet($name);
	if (template_exists($name))
	{
		$d->update('options', array('option_value'=>$name), "option_name='theme'");
		if ($d->affected_rows())
		{
			if (file_exists(root_dir.'templates/'.$options['theme'].'/admin.php'))
			{
				require_once(root_dir.'templates/'.$options['theme'].'/admin.php');
				if (function_exists('template_'.str_replace('-', '_', $options['theme']).'_inactive'))
				{
					$inactive = 'template_'.str_replace('-', '_', $options['theme']).'_inactive';
					$inactive();
				}
			}

			if (file_exists(root_dir.'templates/'.$name.'/admin.php'))
			{
				require_once(root_dir.'templates/'.$name.'/admin.php');
				if (function_exists('template_'.str_replace('-', '_', $name).'_active'))
				{
					$active = 'template_'.str_replace('-', '_', $name).'_active';
					$active();
				}
			}

			remove_cache('options');
			$result = 'success';
		}
		else
		{
			$result = 'error';
		}
	}
	exit('{"result":"'.$result.'"}');
}

function _upload()
{
	global $tpl, $options, $page, $d;
	if (isset($_FILES['myfile']))
	{
		header('Content-type: text/html; charset='.charset);
		if (get_extension($_FILES['myfile']['name']) == 'zip')
		{
			require_once(engine_dir.'upload.class.php');
			$upload = upload::file($_FILES['myfile'], root_dir.'templates');
			$result = isset($upload['error'])? 0 : 1;
			
			if ($result)
			{
				$zip_path = $upload['path'].'/'.$upload['filename'];
				$extract = apadana_extract_zip($zip_path, $upload['path']);
				
				if ($extract === true)
				{
					$result = '<font color=green>تم با موفقیت آپلود شد.<br>با رفتن به تب فهرست تم ها می توانید تم <b>'.str_ireplace('.zip', null, $upload['filename']).'</b> را فعال کنید!</font>';
				}
				else
				{
					$result = '<font color=red>'.(is_string($extract) ? $extract : 'در باز کردن فایل زیپ خطایی رخ داده').'</font>';
				}

				@unlink($zip_path);
			}
			else
			{
				$result = '<font color=red>در آپلود تم خطایی رخ داده!</font>';
			}
		}
		else
		{
			$result = '<font color=red>فقط فایل زیپ مجاز است!</font>';
		}
		echo $result;
	}
	exit;
}

function _admin()
{
	global $options;
	if (file_exists(root_dir.'templates/'.$options['theme'].'/admin.php'))
	{
		require_once(root_dir.'templates/'.$options['theme'].'/admin.php');
		$func = 'template_'.str_replace('-', '_', $options['theme']).'_admin';

		if (function_exists($func))
		{
			$func();
		}
		else
		{
			redirect(admin_page.'&section=templates');
		}
	}
	else
	{
		redirect(admin_page.'&section=templates');
	}
}

function _files($dir)
{
	if ($dh = opendir($dir))
	{
		$files = Array();
		$inner_files = Array();
		while($file = readdir($dh))
		{
			if ($file != '.' && $file != '..' && $file[0] != '.')
			{
				if (is_dir($dir . '/' . $file))
				{
					$inner_files = _files($dir . '/' . $file);
	
					if (is_array($inner_files) && count($inner_files))
						$files = array_merge($files, $inner_files);
				}
				else
				{
					array_push($files, $dir . '/' . $file);
				}
			}
		}
		closedir($dh);
		return $files;
	}
}

function _edit()
{
	global $tpl, $options, $page, $d;

	$name = get_param($_GET, 'name');

	if (is_alphabet($name) && is_dir(root_dir.'templates/'.$name))
	{
		if (isset($_POST['new']))
		{
			$new = get_param($_POST, 'new');
			$new = nohtml($new);
			$new = str_replace('..', null, $new);

			if (empty($new))
			{
				exit('فیلد لازم را پر کنید!');
			}

			if (get_extension($new) == '')
			{
				if (is_dir(root_dir.'templates/'.$name.'/'.$new))
				{
					echo 'این پوشه وجود دارد!';
				}
				else
				{
					if (@mkdir(root_dir.'templates/'.$name.'/'.$new))
						echo 'پوشه ساخته شد!';
					else
						echo 'در ساختن پوشه خطایی رخ داده!';
				}
			}
			else
			{
				if (file_exists(root_dir.'templates/'.$name.'/'.$new))
				{
					echo 'این فایل وجود دارد!';
				}
				else
				{
					if (@file_put_contents(root_dir.'templates/'.$name.'/'.$new, ' '))
						echo 'OK';
					else
						echo 'در ساختن فایل خطایی رخ داده!';
				}
			}
			exit;
		}
		
		$file = get_param($_POST, 'file');
		$file = nohtml($file);
		
		if (!empty($file))
		{
			$file = str_replace('..', null, $file);

			if (file_exists(root_dir.'templates/'.$name.'/'.$file))
			{
				if (isset($_POST['contents']))
				{
					$contents = get_param($_POST, 'contents', null, 1);

					if (is_writable(root_dir.'templates/'.$name.'/'.$file))
					{
						echo 'فایل ویرایش شد!';
						file_put_contents(root_dir.'templates/'.$name.'/'.$file, $contents);
					}
					else
					{
						echo 'سیستم دسترسی لازم برای ویرایش این فایل را ندارد!';
					}
				}
				else
				{
					echo @file_get_contents(root_dir.'templates/'.$name.'/'.$file);
				}
				exit;
			}
			else
			{
				exit( md5(member_id.member_name.group_rights) );
			}
		}
		else
		{
			set_title('ویرایش تم');
			$list = _files(root_dir.'templates/'.$name);

			$files = array('html', 'htm', 'php', 'txt', 'tpl', 'css', 'inc', 'ihtml','js');
			$itpl = new template('engine/admin/template/templates-edit.tpl');
			
			foreach($list as $f)
			{
				if (!in_array(get_extension($f), $files)) continue;

				$f = str_replace(root_dir.'templates/'.$name.'/', null, $f);

				$itpl->add_for('files', array(
					'{file}' => $f,
				));
			}
			
			$itpl->assign(array(
				'{template}' => $name,
				'{error}' => md5(member_id.member_name.group_rights),
			));

			/**
			* CodeMirror Library files
			* @since 1.1
			**/
			set_link('codemirror_dtheme',url.'engine/javascript/codemirror/lib/codemirror.css');
			set_link('codemirror_theme',url.'engine/javascript/codemirror/theme/monokai.css');
			set_link('codemirror_addon_dialog',url.'engine/javascript/codemirror/addon/dialog/dialog.css');
			set_link('codemirror_addon_fullscreen',url.'engine/javascript/codemirror/addon/display/fullscreen.css');

			set_script('codemirror',url.'engine/javascript/codemirror/lib/codemirror.js');
			set_script('codemirror_addon_loadmode',url.'engine/javascript/codemirror/addon/mode/loadmode.js');
			set_script('codemirror_addon_search',url.'engine/javascript/codemirror/addon/search/search.js');
			set_script('codemirror_addon_searchcursor',url.'engine/javascript/codemirror/addon/search/searchcursor.js');
			set_script('codemirror_addon_dialog',url.'engine/javascript/codemirror/addon/dialog/dialog.js');
			set_script('codemirror_addon_matchbrackets',url.'engine/javascript/codemirror/addon/edit/matchbrackets.js');
			set_script('codemirror_addon_closebrackets',url.'engine/javascript/codemirror/addon/edit/closebrackets.js');
			set_script('codemirror_addon_comment',url.'engine/javascript/codemirror/addon/comment/comment.js');
			set_script('codemirror_addon_fullscreen',url.'engine/javascript/codemirror/addon/display/fullscreen.js');
			set_script('codemirror_meta',url.'engine/javascript/codemirror/mode/meta.js');
			set_script('codemirror_keymap',url.'engine/javascript/codemirror/keymap/sublime.js');

			set_content(false, $itpl->get_var());
			unset($itpl);
		}
	}
	else
	{
		redirect(admin_page.'&section=templates');
	}
}

function _get_info()
{
	$name = get_param($_GET, 'name');

	$json = array(
		'message' => array(),
		'result' => 'error'
	);

	if (!is_alphabet($name))
	{
		$json['message'][] = 'نام قالب مورد نظر معتبر نیست!';
	}
	else
	{
		if (!template_exists($name))
		{
			$json['message'][] = 'قالب مورد نظر در سیستم وجود ندارد و یا ناقص است!';
		}
	}

	if (count($json['message']))
	{
		$json['message'] = implode('<br>', $json['message']);
	}
	else
	{
		$json['result'] = 'success';

		$info = template_info($name);
		$screenshot = empty($info['screenshot']) || !file_exists(root_dir.'templates/'.$name.'/'.$info['screenshot'])? url.'engine/images/screenshots.png' : url.'templates/'.$name.'/'.$info['screenshot'];
		$json['info']  = '<center><img src="'. $screenshot .'" id="templates-infoBox-screenshot" width="180" style="margin:6px" /></center>';
		$json['info']  .= '<div style="margin-bottom:4px;padding-bottom:4px"><b>نام قالب</b>:&nbsp;&nbsp;'.(apadana_strtolower($info['name']) != apadana_strtolower($name)? $info['name'].' <span style="visibility:hidden;font-size:2px">z</span><span style="color:#487d8c;font-size:10px">('.$name.')</span><span style="visibility:hidden;font-size:2px">z</span>' : $name).'</div>';
		$json['info'] .= '<div style="margin-bottom:4px;padding-bottom:4px"><b>نگارش قالب</b>:&nbsp;&nbsp;'.translate_number($info['version']).' <span style="visibility:hidden;font-size:2px">z</span><span style="color:#487d8c;font-size:10px">('.(apadana_compare($info['compatibility'])? 'بر اساس گفته سازنده با نسخه آپادانا شما سازگار است' : '<span style="color:red;">با نگارش آپادانا ی شما سازگار نیست</span>').')</span><span style="visibility:hidden;font-size:2px">z</span></div>';
		$json['info'] .= '<div style="margin-bottom:4px;padding-bottom:4px"><b>تاریخ ساخت</b>:&nbsp;&nbsp;'.apadana_date('l j F Y ساعت g:i A', strtotime($info['creation-date'])).'</div>';
		$json['info'] .= !empty($info['description']) && $info['description'] != 'unknown'? '<div style="margin-bottom:4px;padding-bottom:4px"><b>توضیحات سازنده</b>:&nbsp;&nbsp;<br>'.$info['description'].'</div>' : null;
		$json['info'] .= !empty($info['author']) && $info['author'] != 'unknown'? '<div style="margin-bottom:4px;padding-bottom:4px"><b>نام سازنده</b>:&nbsp;&nbsp;'.$info['author'].'</div>' : null;
		$json['info'] .= !empty($info['author-email']) && $info['author-email'] != 'unknown'? '<div style="margin-bottom:4px;padding-bottom:4px"><b>رایانامه سازنده</b>:&nbsp;&nbsp;'.$info['author-email'].'</div>' : null;
		$json['info'] .= !empty($info['author-url']) && $info['author-url'] != 'unknown'? '<div style="margin-bottom:4px;padding-bottom:4px"><b>وب‌سایت سازنده</b>:&nbsp;&nbsp;<a href="'.redirect_link($info['author-url']).'" target="_blank">'.basename($info['author-url']).'</a></div>' : null;
		$json['info'] .= !empty($info['license']) && $info['license'] != 'unknown'? '<div style="margin-bottom:4px;padding-bottom:4px"><b>مجوز قالب</b>:&nbsp;&nbsp;'.$info['license'].'</div>' : null;
		$json['info'] .= !empty($info['positions']) ? '<div style="margin-bottom:4px;padding-bottom:4px"><b>موقعیت ها</b>:&nbsp;&nbsp;'.$info['positions'].'</div>' : null;
		$json['info'] .= !empty($info['pages']) ? '<div style="margin-bottom:4px;padding-bottom:4px"><b>صفحه ها</b>:&nbsp;&nbsp;'.$info['pages'].'</div>' : null;
		$json['info'] .= '<div style="margin-bottom:4px;padding-bottom:4px"><b>فشرده سازی اچ تی ام ال</b>:&nbsp;&nbsp;'.($info['html-compression'] ? 'فعال' : 'غیر فعال' ).'</div>';
	}

	exit(json_encode($json));
}

$_GET['do'] = get_param($_GET, 'do');

switch($_GET['do'])
{
	case 'get_info':
	_get_info();
	break;

	case 'default':
	_default();
	break;

	case 'upload':
	_upload();
	break;

	case 'admin':
	_admin();
	break;
	
	case 'edit':
	_edit();
	break;
	
	default:
	_index();
	break;
}

?>