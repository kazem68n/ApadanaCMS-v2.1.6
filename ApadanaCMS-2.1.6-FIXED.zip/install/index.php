<?php
/**
 * Apadana installer bootstrap — 2.1.6
 */
@session_start();
@ob_start();
@ob_implicit_flush(0);

error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);
@ini_set('display_errors', '1');

define('security', true);
define('root_dir', dirname(dirname(__FILE__)).'/');
define('engine_dir', root_dir.'engine/');
define('install_dir', root_dir.'install/');
define('modules_dir', root_dir.'modules/');

define('member', 0);
define('member_id', 0);
define('member_name', 'GUEST');
define('member_group', 5);
$member = 0;
define('group_admin', 0);
define('group_super_admin', 0);
define('group_rights', null);

if (file_exists(engine_dir.'config.inc.php') && filesize(engine_dir.'config.inc.php') > 50
	&& file_exists(install_dir.'apadana.lock')
	&& !file_exists(install_dir.'reinstall.allow'))
{
	header('Content-Type: text/html; charset=utf-8');
	exit('آپادانا قبلاً نصب شده است. پوشه install را حذف کنید.');
}

require_once engine_dir.'functions.php';
require_once engine_dir.'filter.function.php';
require_once engine_dir.'template.class.php';

$tpl = new template('init.tpl', install_dir.'template/', false);

if (!file_exists(install_dir.'apadana.lock'))
{
	if (isset($_GET['section']) && in_array($_GET['section'], array('install', 'upgrade'), true))
	{
		require_once install_dir.$_GET['section'].'.php';
	}
	else
	{
		$itpl = new template('index.tpl', install_dir.'template/', false);
		$itpl->assign(array('[open]' => null, '[/open]' => null));
		$itpl->block('#\\[lock\\](.*?)\\[/lock\\]#s', '');
	}
}
else
{
	$itpl = new template('index.tpl', install_dir.'template/', false);
	$itpl->assign(array('[lock]' => null, '[/lock]' => null));
	$itpl->block('#\\[open\\](.*?)\\[/open\\]#s', '');
}

$tpl->assign('{title}', isset($title) && $title != null ? $title : null);
$tpl->assign('{content}', isset($itpl) ? $itpl->get_var() : '');
unset($itpl);
$tpl->display();
