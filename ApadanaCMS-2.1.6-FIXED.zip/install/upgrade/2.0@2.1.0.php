<?php
defined('security') or exit('Direct Access to this location is not allowed.');
global $d;
$d->query("ALTER TABLE `#__members` MODIFY `member_password` VARCHAR(255) NOT NULL DEFAULT ''");
echo message('member_password column upgraded to VARCHAR(255).', 'success');
